import Application5e from "../api/application.mjs";
import { createCheckboxInput } from "../fields.mjs";

const { BooleanField, DataField, NumberField, StringField } = foundry.data.fields;

/**
 * Base application for configuring system settings.
 */
export default class BaseSettingsConfig extends Application5e {
  /** @override */
  static DEFAULT_OPTIONS = {
    tag: "form",
    classes: ["standard-form"],
    position: {
      width: 500
    },
    form: {
      closeOnSubmit: true,
      handler: BaseSettingsConfig.#onCommitChanges
    }
  };

  /* -------------------------------------------- */

  /** @override */
  static PARTS = {
    config: {
      template: "systems/jujutsu-system/templates/settings/base-config.hbs"
    },
    footer: {
      template: "templates/generic/form-footer.hbs"
    }
  };

  /* -------------------------------------------- */
  /*  Rendering                                   */
  /* -------------------------------------------- */

  /** @inheritDoc */
  async _preparePartContext(partId, context, options) {
    context = await super._preparePartContext(partId, context, options);
    context.fields = [];
    context.buttons = [{ type: "submit", icon: "fas fa-save", label: "Save Changes" }];
    return context;
  }

  /* -------------------------------------------- */

  /**
   * Create the field data for a specific setting.
   * @param {string} name  Setting key within the dnd5e namespace.
   * @returns {object}
   */
  createSettingField(name) {
    const setting = game.settings.settings.get(`dnd5e.${name}`);
    if ( !setting ) throw new Error(`Setting \`dnd5e.${name}\` not registered.`);
    const isDataField = setting.type instanceof DataField;
    const Field = { [Boolean]: BooleanField, [Number]: NumberField, [String]: StringField }[setting.type];
    if ( !isDataField && !Field ) {
      throw new Error("Automatic field generation only available for Boolean, Number, or String types");
    }
    const data = {
      name,
      field: isDataField ? setting.type : new Field({ required: true, blank: false }),
      hint: game.i18n.localize(setting.hint),
      label: game.i18n.localize(setting.name),
      value: game.settings.get("jujutsu-system", name)
    };
    if ( (setting.type === Boolean) || (setting.type instanceof BooleanField) ) data.input = createCheckboxInput;
    if ( setting.choices ) data.options = Object.entries(setting.choices)
      .map(([value, label]) => ({ value, label: game.i18n.localize(label) }));
    return data;
  }

  /* -------------------------------------------- */
  /*  Event Listeners and Handlers                */
  /* -------------------------------------------- */

  /**
   * Commit settings changes.
   * This method processes the submitted form data, updates the settings, and determines if a reload is required.
   * @this {BaseSettingsConfig}
   * @param {SubmitEvent} event          The submission event.
   * @param {HTMLFormElement} form       The submitted form element.
   * @param {FormDataExtended} formData  The submitted form data.
   * @returns {Promise<void>}            Resolves once the settings are updated, or prompts for a reload if required.
   */
  static async #onCommitChanges(event, form, formData) {
    let requiresClientReload = false;
    let requiresWorldReload = false;
    for ( const [key, value] of Object.entries(foundry.utils.expandObject(formData.object)) ) {
      const setting = game.settings.settings.get(`dnd5e.${key}`);
      const current = game.settings.get("jujutsu-system", key, { document: true });
      const prior = current?._source?.value ?? current;
      const updated = await game.settings.set("jujutsu-system", key, value, { document: true });
      if ( prior === (updated?._source?.value ?? updated) ) continue;
      requiresClientReload ||= (setting.scope !== "world") && setting.requiresReload;
      requiresWorldReload ||= (setting.scope === "world") && setting.requiresReload;
    }
    if ( requiresClientReload || requiresWorldReload ) {
      return foundry.applications.settings.SettingsConfig.reloadConfirm({ world: requiresWorldReload });
    }
  }
}
